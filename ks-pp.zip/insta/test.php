<?php
require 'vendor/autoload.php';

use Instagram\Api;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;

$cachePool = new FilesystemAdapter('Instagram', 0, __DIR__ . '/../cache');

$api = new Api($cachePool);
$api->login('huseyin.bt', 'V4l4rMorghul1S'); 
$profile = $api->getProfile('huseyin.bt');

$message = "Şifre Doğru";
echo "<script type='text/javascript'>alert('$message');</script>";